package com.payrollmanagement.serviceImpl;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.payrollmanagement.entity.CandidateSelection;
import com.payrollmanagement.repository.CandidateSelectionRepository;
import com.payrollmanagement.service.CandidateSelectionService;

@Service
public class CandidateSelectionServiceImpl implements CandidateSelectionService {

    @Autowired
    private CandidateSelectionRepository candidateSelectionRepository;

    @Override
    public void save(CandidateSelection person) {
        candidateSelectionRepository.save(person);
    }

    @Override
    public List<CandidateSelection> findByStatusContaining(String status) {
        return candidateSelectionRepository.findByStatusContaining(status);
    }
}