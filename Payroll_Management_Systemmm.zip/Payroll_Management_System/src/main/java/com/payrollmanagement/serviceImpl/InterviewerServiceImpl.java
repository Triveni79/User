package com.payrollmanagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payrollmanagement.entity.Interviewer;
import com.payrollmanagement.repository.InterviewerRepository;
import com.payrollmanagement.service.InterviewerService;

@Service
public class InterviewerServiceImpl implements InterviewerService {
    
    @Autowired
    private InterviewerRepository interviewerRepository;

    @Override
    public List<Interviewer> getAllInterviewers() {
        return interviewerRepository.findAll();
    }

    @Override
    public Interviewer createInterviewer(Interviewer interviewer) {
        String stati = "INT";
        String employeeid = String.format("%03d", Integer.parseInt(interviewer.getEmployeeid()));
        String result = stati.concat(employeeid);
        interviewer.setInterviewerid(result);
        return interviewerRepository.save(interviewer);
    }
}
