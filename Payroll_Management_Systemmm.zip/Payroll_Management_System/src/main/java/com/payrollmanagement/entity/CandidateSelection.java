package com.payrollmanagement.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "interview_Process")
public class CandidateSelection {
	
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String interviwerId;    
    private String interviwer;
    private String status;
    private String remarks;
    private int round;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInterviwerId() {
		return interviwerId;
	}
	public void setInterviwerId(String interviwerId) {
		this.interviwerId = interviwerId;
	}
	public String getInterviwer() {
		return interviwer;
	}
	public void setInterviwer(String interviwer) {
		this.interviwer = interviwer;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	@Override
	public String toString() {
		return "CandidateSelection [id=" + id + ", interviwerId=" + interviwerId + ", interviwer=" + interviwer
				+ ", status=" + status + ", remarks=" + remarks + ", round=" + round + "]";
	}
	public CandidateSelection(int id, String interviwerId, String interviwer, String status, String remarks,
			int round) {
		super();
		this.id = id;
		this.interviwerId = interviwerId;
		this.interviwer = interviwer;
		this.status = status;
		this.remarks = remarks;
		this.round = round;
	}
	public CandidateSelection() {
		super();
		// TODO Auto-generated constructor stub
	}	
    
    
    
}