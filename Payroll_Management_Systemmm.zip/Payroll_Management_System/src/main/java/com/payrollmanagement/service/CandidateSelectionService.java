package com.payrollmanagement.service;



import java.util.List;

import com.payrollmanagement.entity.CandidateSelection;

public interface CandidateSelectionService {

    void save(CandidateSelection person);

    List<CandidateSelection> findByStatusContaining(String status);
}