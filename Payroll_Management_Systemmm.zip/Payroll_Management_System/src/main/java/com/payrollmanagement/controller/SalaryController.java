package com.payrollmanagement.controller;




import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.payrollmanagement.entity.AddCandidate;
import com.payrollmanagement.entity.AddEmployee;
import com.payrollmanagement.entity.Salary;
import com.payrollmanagement.repository.AddCandidateRepo;
import com.payrollmanagement.repository.AddEmployeeRepo;
import com.payrollmanagement.repository.EmpRepo;
import com.payrollmanagement.service.SalaryService;

import jakarta.servlet.http.HttpServletResponse;



@RestController
@RequestMapping("/api")
public class SalaryController {

	@Autowired
	private SalaryService serviceInter;

	
	
		// save details for pranav EMP (salary)
	@PostMapping("/details")
	public Salary Details(@RequestBody Salary e) {

		return serviceInter.saveEmpp(e);

	}


}
