package com.payrollmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payrollmanagement.entity.Interviewer;
import com.payrollmanagement.service.InterviewerService;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class InterviewerController {
    
    @Autowired
    private InterviewerService interviewerService;

    @GetMapping("/interviewer")
    public List<Interviewer> getAllInterviewers(){
        return interviewerService.getAllInterviewers();
    }

    @PostMapping("/interviewer")
    public Interviewer createInterviewer(@RequestBody Interviewer interviewer) {
        return interviewerService.createInterviewer(interviewer);
    }
}
