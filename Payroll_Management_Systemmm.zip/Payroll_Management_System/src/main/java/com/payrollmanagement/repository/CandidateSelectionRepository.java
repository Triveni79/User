package com.payrollmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payrollmanagement.entity.CandidateSelection;

public interface CandidateSelectionRepository extends JpaRepository<CandidateSelection, String> {
	List<CandidateSelection> findByStatusContaining(String status);
}
