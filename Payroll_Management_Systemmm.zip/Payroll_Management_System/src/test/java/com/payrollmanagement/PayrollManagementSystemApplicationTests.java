package com.payrollmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayrollManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
